import json
from models import LearningPathResponse
from gemini_client import generate_text
from config import settings


LEARNING_SCHEMA = {
    "type": "object",
    "properties": {
        "topic": {"type": "string"},
        "overview": {"type": "string"},
        "steps": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "level": {"type": "string"},
                    "topics": {"type": "array", "items": {"type": "string"}},
                    "suggested_time": {"type": "string"},
                    "resources": {"type": "array", "items": {"type": "string"}}
                },
                "required": ["level", "topics", "suggested_time", "resources"]
            }
        }
    },
    "required": ["topic", "overview", "steps"]
}


async def get_learning_recommendations(topic: str) -> LearningPathResponse:
    topic = topic[:settings.max_input_chars]
    prompt = f"""
Create a structured learning path for: {topic}

Requirements:
- Start at beginner level and progress to advanced.
- Organize concepts in a sensible prerequisite order.
- Give a practical suggested time for each level.
- Suggest resource TYPES or reputable resource names, not fabricated URLs.
- Keep the plan realistic for a student.
"""
    raw = await generate_text(
        prompt,
        system_instruction="You are an educational curriculum planner.",
        response_schema=LEARNING_SCHEMA,
        max_output_tokens=1800,
    )
    try:
        return LearningPathResponse.model_validate(json.loads(raw))
    except Exception as exc:
        raise ValueError(f"Could not validate learning path: {exc}") from exc
