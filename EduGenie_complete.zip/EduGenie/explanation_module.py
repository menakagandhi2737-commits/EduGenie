from gemini_client import generate_text
from models import ExplainResponse
from config import settings


def _local_explainer(topic: str) -> str:
    try:
        from transformers import pipeline
        generator = pipeline(
            "text2text-generation",
            model=settings.local_explainer_model,
        )
        result = generator(
            f"Explain this concept simply for a beginner: {topic}",
            max_new_tokens=250,
            do_sample=False,
        )
        return result[0]["generated_text"].strip()
    except Exception:
        return ""


async def explain_concept(topic: str) -> ExplainResponse:
    topic = topic[:settings.max_input_chars]

    if settings.enable_local_explainer:
        local = _local_explainer(topic)
        if local:
            return ExplainResponse(explanation=local, source="local-LaMini-Flan-T5")

    prompt = f"""
Explain the educational concept below to a beginner.

CONCEPT:
{topic}

Structure:
1. Simple definition
2. How it works
3. Small real-world or programming example if relevant
4. One-line recap

Use simple language and avoid unnecessary jargon.
"""
    explanation = await generate_text(
        prompt,
        system_instruction="You are a patient teacher who simplifies difficult concepts.",
        max_output_tokens=1100,
    )
    return ExplainResponse(explanation=explanation, source="gemini")
