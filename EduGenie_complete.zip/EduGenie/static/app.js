const task = document.getElementById("task");
const input = document.getElementById("inputText");
const inputLabel = document.getElementById("inputLabel");
const submitBtn = document.getElementById("submitBtn");
const clearBtn = document.getElementById("clearBtn");
const copyBtn = document.getElementById("copyBtn");
const result = document.getElementById("result");
const status = document.getElementById("status");

const taskInfo = {
  qa: ["Your question", "Example: What is a binary search tree?"],
  explain: ["Concept to explain", "Example: Explain polymorphism in simple words."],
  quiz: ["Topic or passage", "Paste a topic or educational passage to generate 3 MCQs."],
  summarize: ["Text to summarize", "Paste the educational text you want to summarize."],
  learn: ["Topic to learn", "Example: Python, SQL, Data Structures, Cloud Computing."]
};

task.addEventListener("change", () => {
  const info = taskInfo[task.value];
  inputLabel.textContent = info[0];
  input.placeholder = info[1];
});

clearBtn.addEventListener("click", () => {
  input.value = "";
  result.textContent = "Your AI-generated learning result will appear here.";
  result.className = "result empty";
  status.textContent = "Ready";
});

copyBtn.addEventListener("click", async () => {
  await navigator.clipboard.writeText(result.innerText);
  status.textContent = "Copied";
  setTimeout(() => status.textContent = "Ready", 1200);
});

function showError(message) {
  result.className = "result";
  result.textContent = `Error: ${message}`;
}

function renderQuiz(data) {
  result.className = "result";
  result.innerHTML = "";

  data.questions.forEach((q, index) => {
    const box = document.createElement("div");
    box.className = "quiz-question";

    const title = document.createElement("h3");
    title.textContent = `${index + 1}. ${q.question}`;
    box.appendChild(title);

    q.options.forEach(option => {
      const button = document.createElement("button");
      button.className = "quiz-option";
      button.textContent = option;
      button.onclick = () => {
        box.querySelectorAll(".quiz-option").forEach(b => b.disabled = true);
        if (option === q.correct_answer) {
          button.classList.add("correct");
        } else {
          button.classList.add("wrong");
          box.querySelectorAll(".quiz-option").forEach(b => {
            if (b.textContent === q.correct_answer) b.classList.add("correct");
          });
        }
        const explanation = document.createElement("p");
        explanation.textContent = `Explanation: ${q.explanation}`;
        box.appendChild(explanation);
      };
      box.appendChild(button);
    });

    result.appendChild(box);
  });
}

function renderLearningPath(data) {
  result.className = "result";
  result.innerHTML = `<h3>${escapeHtml(data.topic)}</h3><p>${escapeHtml(data.overview)}</p>`;

  data.steps.forEach(step => {
    const div = document.createElement("div");
    div.className = "path-step";
    div.innerHTML = `
      <strong>${escapeHtml(step.level)}</strong>
      <p><b>Suggested time:</b> ${escapeHtml(step.suggested_time)}</p>
      <b>Topics</b>
      <ul>${step.topics.map(x => `<li>${escapeHtml(x)}</li>`).join("")}</ul>
      <b>Resources</b>
      <ul>${step.resources.map(x => `<li>${escapeHtml(x)}</li>`).join("")}</ul>
    `;
    result.appendChild(div);
  });
}

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

submitBtn.addEventListener("click", async () => {
  const text = input.value.trim();
  if (!text) {
    showError("Please enter some text first.");
    return;
  }

  const endpoint = {
    qa: "/qa",
    explain: "/explain",
    quiz: "/quiz",
    summarize: "/summarize",
    learn: "/learn/recommendations"
  }[task.value];

  submitBtn.disabled = true;
  status.textContent = "Generating...";
  result.className = "result";
  result.textContent = "EduGenie is working...";

  try {
    const response = await fetch(endpoint, {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({text})
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.detail || "Request failed.");
    }

    if (task.value === "qa") {
      result.textContent = data.answer;
    } else if (task.value === "explain") {
      result.textContent = `${data.explanation}\n\nSource: ${data.source}`;
    } else if (task.value === "summarize") {
      result.textContent = data.summary;
    } else if (task.value === "quiz") {
      renderQuiz(data);
    } else if (task.value === "learn") {
      renderLearningPath(data);
    }

    status.textContent = "Done";
  } catch (error) {
    showError(error.message);
    status.textContent = "Error";
  } finally {
    submitBtn.disabled = false;
  }
});
