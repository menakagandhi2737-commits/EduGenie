from functools import lru_cache
from google import genai
from google.genai import types
from fastapi import HTTPException

from config import settings


@lru_cache
def get_client():
    if not settings.gemini_api_key:
        return None
    return genai.Client(api_key=settings.gemini_api_key)


async def generate_text(prompt: str, *, system_instruction: str | None = None,
                        response_schema=None, max_output_tokens: int = 1200) -> str:
    client = get_client()
    if client is None:
        raise HTTPException(
            status_code=503,
            detail="Gemini API is not configured. Add GEMINI_API_KEY to .env."
        )

    try:
        config_kwargs = {
            "temperature": 0.4,
            "max_output_tokens": max_output_tokens,
        }
        if system_instruction:
            config_kwargs["system_instruction"] = system_instruction
        if response_schema is not None:
            config_kwargs["response_mime_type"] = "application/json"
            config_kwargs["response_schema"] = response_schema

        response = client.models.generate_content(
            model=settings.gemini_model,
            contents=prompt,
            config=types.GenerateContentConfig(**config_kwargs),
        )
        text = getattr(response, "text", None)
        if not text:
            raise HTTPException(status_code=502, detail="Gemini returned an empty response.")
        return text.strip()
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=502, detail=f"Gemini request failed: {exc}") from exc
