from typing import List
from pydantic import BaseModel, Field


class TextRequest(BaseModel):
    text: str = Field(min_length=1, max_length=12000)


class QAResponse(BaseModel):
    answer: str


class ExplainResponse(BaseModel):
    explanation: str
    source: str = "gemini"


class SummaryResponse(BaseModel):
    summary: str


class QuizQuestion(BaseModel):
    question: str
    options: List[str] = Field(min_length=4, max_length=4)
    correct_answer: str
    explanation: str


class QuizResponse(BaseModel):
    questions: List[QuizQuestion]


class LearningStep(BaseModel):
    level: str
    topics: List[str]
    suggested_time: str
    resources: List[str]


class LearningPathResponse(BaseModel):
    topic: str
    overview: str
    steps: List[LearningStep]
