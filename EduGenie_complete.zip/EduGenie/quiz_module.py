import json
from models import QuizResponse
from gemini_client import generate_text
from config import settings


QUIZ_SCHEMA = {
    "type": "object",
    "properties": {
        "questions": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "question": {"type": "string"},
                    "options": {
                        "type": "array",
                        "items": {"type": "string"}
                    },
                    "correct_answer": {"type": "string"},
                    "explanation": {"type": "string"}
                },
                "required": ["question", "options", "correct_answer", "explanation"]
            }
        }
    },
    "required": ["questions"]
}


def clean_json_block(text: str) -> str:
    text = text.strip()
    if text.startswith("```"):
        lines = text.splitlines()
        if lines and lines[0].startswith("```"):
            lines = lines[1:]
        if lines and lines[-1].strip() == "```":
            lines = lines[:-1]
        text = "\n".join(lines).strip()
    return text


async def generate_quiz(passage: str) -> QuizResponse:
    passage = passage[:settings.max_input_chars]
    prompt = f"""
Create exactly 3 multiple-choice questions from the educational content below.

CONTENT:
{passage}

Rules:
- Exactly 3 questions.
- Exactly 4 options per question.
- One correct option per question.
- correct_answer must exactly match one option.
- Include a short explanation for the correct answer.
- Questions must be answerable from the supplied content.
"""
    raw = await generate_text(
        prompt,
        system_instruction="You create reliable educational MCQs.",
        response_schema=QUIZ_SCHEMA,
        max_output_tokens=1500,
    )

    try:
        data = json.loads(clean_json_block(raw))
        result = QuizResponse.model_validate(data)
        if len(result.questions) != 3:
            raise ValueError("Expected exactly 3 questions.")
        for q in result.questions:
            if len(q.options) != 4 or q.correct_answer not in q.options:
                raise ValueError("Invalid quiz options or answer.")
        return result
    except Exception as exc:
        raise ValueError(f"Could not validate Gemini quiz response: {exc}") from exc
