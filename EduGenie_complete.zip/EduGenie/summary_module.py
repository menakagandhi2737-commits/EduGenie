from gemini_client import generate_text
from models import SummaryResponse
from config import settings


async def summarize_text(text: str) -> SummaryResponse:
    text = text[:settings.max_input_chars]
    prompt = f"""
Summarize the following educational passage for a student.

PASSAGE:
{text}

Requirements:
- Keep the important facts and relationships.
- Remove repetition.
- Use short paragraphs and bullet points where useful.
- Do not add information that is not supported by the passage.
"""
    summary = await generate_text(
        prompt,
        system_instruction="You summarize educational material accurately without adding unsupported facts.",
        max_output_tokens=1000,
    )
    return SummaryResponse(summary=summary)
