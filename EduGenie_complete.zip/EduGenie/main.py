from pathlib import Path
from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates

from models import (
    TextRequest, QAResponse, ExplainResponse, QuizResponse,
    SummaryResponse, LearningPathResponse
)
from qna import answer_question
from explanation_module import explain_concept
from quiz_module import generate_quiz
from summary_module import summarize_text
from learning_path import get_learning_recommendations
from config import settings

BASE_DIR = Path(__file__).resolve().parent

app = FastAPI(
    title="EduGenie - Google Gemini Powered Learning Assistant",
    version="1.0.0",
    description="Educational assistant for Q&A, explanations, quizzes, summaries and learning paths."
)

app.mount("/static", StaticFiles(directory=BASE_DIR / "static"), name="static")
templates = Jinja2Templates(directory=BASE_DIR / "templates")


@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    return templates.TemplateResponse(
        request=request,
        name="index.html",
        context={"app_name": settings.app_name}
    )


@app.get("/health")
async def health():
    return {
        "status": "ok",
        "gemini_configured": bool(settings.gemini_api_key),
        "model": settings.gemini_model,
        "local_explainer_enabled": settings.enable_local_explainer,
    }


@app.post("/qa", response_model=QAResponse)
async def qa(payload: TextRequest):
    return await answer_question(payload.text)


@app.post("/explain", response_model=ExplainResponse)
async def explain(payload: TextRequest):
    return await explain_concept(payload.text)


@app.post("/quiz", response_model=QuizResponse)
async def quiz(payload: TextRequest):
    return await generate_quiz(payload.text)


@app.post("/summarize", response_model=SummaryResponse)
async def summarize(payload: TextRequest):
    return await summarize_text(payload.text)


@app.post("/learn/recommendations", response_model=LearningPathResponse)
async def recommendations(payload: TextRequest):
    return await get_learning_recommendations(payload.text)
