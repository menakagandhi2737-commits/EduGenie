from gemini_client import generate_text
from models import QAResponse
from config import settings


async def answer_question(question: str) -> QAResponse:
    question = question[:settings.max_input_chars]
    prompt = f"""
Answer the student's question accurately and clearly.

Question:
{question}

Rules:
- Use simple educational language.
- Give the direct answer first.
- Add a short explanation or example when useful.
- If the question is ambiguous, state the assumption briefly.
- Do not invent sources or facts.
"""
    answer = await generate_text(
        prompt,
        system_instruction="You are EduGenie, a concise and supportive educational assistant.",
        max_output_tokens=900,
    )
    return QAResponse(answer=answer)
