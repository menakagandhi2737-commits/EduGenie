# EduGenie — Google Gemini Powered Learning Assistant

EduGenie is a FastAPI + HTML/CSS/JavaScript learning assistant based on the supplied project documentation.

## Features

- Q&A
- Beginner-friendly concept explanation
- 3-question MCQ quiz generation
- Educational text summarization
- Beginner-to-advanced learning path recommendations
- JSON validation for structured AI responses
- Health/configuration endpoint
- Optional local LaMini-Flan-T5 explainer

## Project structure

```text
EduGenie/
├── main.py
├── config.py
├── models.py
├── gemini_client.py
├── qna.py
├── explanation_module.py
├── quiz_module.py
├── summary_module.py
├── learning_path.py
├── requirements.txt
├── .env.example
├── .gitignore
├── README.md
├── templates/
│   └── index.html
├── static/
│   ├── style.css
│   └── app.js
└── tests/
    └── test_api.py
```

## 1. Open in VS Code

Open the `EduGenie` folder.

## 2. Create a virtual environment

Windows PowerShell:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
```

If PowerShell blocks activation, use Command Prompt:

```cmd
.venv\Scripts\activate
```

## 3. Install dependencies

```powershell
python -m pip install --upgrade pip
pip install -r requirements.txt
```

## 4. Configure Gemini

Copy `.env.example` to `.env`:

```powershell
Copy-Item .env.example .env
```

Open `.env` and replace:

```text
GEMINI_API_KEY=YOUR_GEMINI_API_KEY_HERE
```

with your API key.

Do not commit `.env` to Git.

## 5. Start the application

```powershell
python -m uvicorn main:app --reload
```

Open:

```text
http://127.0.0.1:8000
```

FastAPI docs:

```text
http://127.0.0.1:8000/docs
```

## 6. Test

Health check:

```text
http://127.0.0.1:8000/health
```

Automated tests:

```powershell
python -m pytest -q
```

## API endpoints

- `POST /qa`
- `POST /explain`
- `POST /quiz`
- `POST /summarize`
- `POST /learn/recommendations`

Each endpoint accepts:

```json
{
  "text": "your question, topic, or passage"
}
```

## Notes

The original document describes Gemini 1.5 Pro and LaMini-Flan-T5. This implementation keeps the same functional separation but uses the current Google GenAI Python SDK pattern and makes the Gemini model configurable through `.env`.

The local LaMini model is optional because downloading a transformer model can be large and can require substantial CPU/RAM. With `ENABLE_LOCAL_EXPLAINER=false`, explanation uses Gemini and the application remains lightweight.

## Troubleshooting

### `ModuleNotFoundError`

Make sure `.venv` is activated and run:

```powershell
pip install -r requirements.txt
```

### Gemini 503 / not configured

Check `.env`:

```text
GEMINI_API_KEY=your_real_key
```

Restart Uvicorn after changing `.env`.

### Port 8000 is busy

```powershell
python -m uvicorn main:app --reload --port 8001
```

Then open `http://127.0.0.1:8001`.

### Model not available

Change `GEMINI_MODEL` in `.env` to a Gemini model available to your API key, then restart the server.
